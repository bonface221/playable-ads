const InitAnimation = () =>{
	let i, objTemp;			
	appMc.mcMain.visible=true;			
	document.getElementById('main').style.visibility = "visible";
	document.getElementById('progress').style.display = "none";	
//	appSounds["bg"].play();
	stateGame = 0;	
}